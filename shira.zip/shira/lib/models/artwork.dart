class Artwork {
  final String title;
  final String artistName;
  final DateTime publisheDate;
  final String bodyText;

  Artwork(this.title, this.artistName, this.publisheDate, this.bodyText);
}
