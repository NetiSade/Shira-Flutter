import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'models/artwork.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Shira',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

final List<Artwork> _artworks = [
  new Artwork(
      'title', 'artistName', DateTime.now(), 'body body body body body body'),
  new Artwork(
      'title1', 'artistName1', DateTime.now(), 'body body body body body body'),
  new Artwork(
      'title2', 'artistName2', DateTime.now(), 'body body body body body body')
];

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        children: _artworks
            .map((artwork) => Card(
                  elevation: 5,
                  margin: EdgeInsets.symmetric(vertical: 8, horizontal: 5),
                  child: ListTile(
                    leading: IconButton(
                      icon: Icon(Icons.favorite),
                      color: Colors.red,
                      onPressed: () => {},
                    ),
                    title: Text(artwork.title),
                    subtitle: Text(artwork.artistName),
                  ),
                ))
            .toList(),
      ),
    );
  }
}
